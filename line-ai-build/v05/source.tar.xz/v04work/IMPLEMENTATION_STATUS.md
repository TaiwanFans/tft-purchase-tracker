# v0.5 實作狀態

- [x] versionCode 5 / versionName 0.5.0
- [x] 固定正式簽章架構：Release 可由外部固定 PKCS12 金鑰簽署；金鑰不進公開 GitHub
- [x] v0.5 永久簽章金鑰已建立，憑證 SHA-256 固定
- [x] 完整備份：寫入後重新讀回 ZIP + SHA-256 + 關聯完整性驗證
- [x] 舊 v0.4 Backup Schema 1 可向後還原；v0.5 使用 Backup Schema 2
- [x] Room DB schema 3：Customer / Conversation / Alias / Case / CaseEvent / Review 分層
- [x] 群組名稱 Alias：高信心才自動合併；中信心進人工待確認
- [x] AI 低信心案件進待確認，不做高風險自動合併
- [x] 案件時間軸：每則有效通知留下 CaseEvent
- [x] 同一聊天室可在前案完成後建立新案件，不再讓聊天室 ID 等於案件 ID
- [x] JSON Agent 匯出新增 conversationId / customerId / aliases / pendingReviews
- [ ] 實機安裝與真實 LINE 通知仍需在 Pixel 10 Pro XL 驗收
