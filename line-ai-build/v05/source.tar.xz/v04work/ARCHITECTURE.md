# v0.5 Architecture

核心分層：

`Raw LINE Notification -> Conversation/Alias -> Customer -> Case -> CaseEvent Timeline -> Draft/Reminder`

安全原則：
- 原始通知只增不改，當作證據層。
- 群組名稱不是永久 ID；Alias 只在高信心或人工確認後綁定。
- 中等相似度不硬合併，建立 ReviewItem。
- 案件與聊天室分離；同一聊天室可先後有多個案件。
- 備份與 Agent JSON 分離；完整備份必須可還原並通過 SHA-256/關聯驗證。
- 正式更新 APK 必須使用同一張簽章憑證。
