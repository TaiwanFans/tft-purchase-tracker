package tw.com.tft.lineai.domain

import tw.com.tft.lineai.data.CasePriority
import tw.com.tft.lineai.data.CaseStatus
import tw.com.tft.lineai.data.CustomerCaseEntity
import tw.com.tft.lineai.data.WaitingFor
import java.time.Instant
import java.time.ZoneId

object CasePriorityEngine {
    data class Result(val priority: CasePriority, val score: Int, val reason: String)
    private val zone = ZoneId.of("Asia/Taipei")

    fun evaluate(case: CustomerCaseEntity, now: Long = System.currentTimeMillis()): Result {
        val status = runCatching { CaseStatus.valueOf(case.status) }.getOrDefault(CaseStatus.OTHER)
        val waiting = runCatching { WaitingFor.valueOf(case.waitingFor) }.getOrDefault(WaitingFor.COMPANY)
        if (status == CaseStatus.RESOLVED) return Result(CasePriority.ARCHIVE, 0, "已結案")

        val latest = case.latestMessage.ifBlank { case.summary }.lowercase()
        val due = case.dueAt
        val hoursToDue = due?.let { (it - now) / 3_600_000.0 }
        val overdue = due != null && due < now
        val dueToday = due != null && sameLocalDay(due, now)

        if (overdue && waiting == WaitingFor.COMPANY) {
            return Result(CasePriority.NOW, 100, "已超過明確期限，現在處理")
        }
        if (hoursToDue != null && hoursToDue in 0.0..2.5 && waiting == WaitingFor.COMPANY) {
            return Result(CasePriority.NOW, 98, "距離期限不到 2.5 小時")
        }

        val hardUrgent = listOf("還沒收到報價", "請盡快", "務必", "10點前", "馬上", "立即", "急用", "不能用", "無法啟動").any(latest::contains)
        if (hardUrgent && waiting == WaitingFor.COMPANY) {
            val score = if (status == CaseStatus.NEED_QUOTE || status == CaseStatus.SERVICE) 100 else 94
            return Result(CasePriority.NOW, score, "最新訊息有明確急迫要求")
        }

        if (waiting in setOf(WaitingFor.CUSTOMER, WaitingFor.VENDOR, WaitingFor.EXTERNAL)) {
            if (dueToday || overdue) {
                return Result(CasePriority.TODAY, 72, "等待${waitingLabel(waiting)}，追蹤日期已到")
            }
            return Result(CasePriority.WAITING, 32, "目前輪到${waitingLabel(waiting)}，先不要佔用今日急件")
        }

        if (dueToday) return Result(CasePriority.TODAY, 88, "有今天的明確期限/行程")

        var score = when (status) {
            CaseStatus.NEED_QUOTE -> 86
            CaseStatus.SERVICE -> 88
            CaseStatus.PAYMENT_RECEIVED -> 84
            CaseStatus.ORDER_CONFIRMED -> 82
            CaseStatus.PREPARE_STOCK -> 84
            CaseStatus.NEED_SHIP -> 86
            CaseStatus.INTERNAL_TASK -> 76
            CaseStatus.NEED_INFO -> 72
            CaseStatus.APPOINTMENT -> 70
            CaseStatus.NEED_FOLLOW_UP -> 58
            CaseStatus.QUOTE_SENT -> 42
            CaseStatus.WAIT_CUSTOMER -> 34
            CaseStatus.WAIT_VENDOR -> 34
            CaseStatus.OTHER -> 20
            CaseStatus.RESOLVED -> 0
        }

        val ageHours = ((now - case.lastEventAt).coerceAtLeast(0L) / 3_600_000L).toInt()
        if (ageHours >= 24 && waiting == WaitingFor.COMPANY && status !in setOf(CaseStatus.OTHER, CaseStatus.QUOTE_SENT)) score += 7
        if (ageHours >= 72 && waiting == WaitingFor.COMPANY && status !in setOf(CaseStatus.OTHER, CaseStatus.QUOTE_SENT)) score += 6
        score = score.coerceAtMost(100)

        return when {
            score >= 90 -> Result(CasePriority.NOW, score, reasonFor(status, case))
            score >= 68 -> Result(CasePriority.TODAY, score, reasonFor(status, case))
            score >= 35 -> Result(CasePriority.LATER, score, reasonFor(status, case))
            else -> Result(CasePriority.ARCHIVE, score, "目前沒有明確公司行動")
        }
    }

    private fun reasonFor(status: CaseStatus, case: CustomerCaseEntity): String = when (status) {
        CaseStatus.NEED_QUOTE -> "客戶/內部正在等報價"
        CaseStatus.QUOTE_SENT -> "已報價，等待後續"
        CaseStatus.WAIT_CUSTOMER -> "等待客戶確認"
        CaseStatus.NEED_INFO -> "缺資料會卡住案件"
        CaseStatus.ORDER_CONFIRMED -> "訂單已確認，需要接續轉單/備貨"
        CaseStatus.PAYMENT_RECEIVED -> "已付款，需要接續內部作業"
        CaseStatus.PREPARE_STOCK -> "需要備貨/清點"
        CaseStatus.NEED_SHIP -> "需要安排出貨/交貨"
        CaseStatus.WAIT_VENDOR -> "等待廠商"
        CaseStatus.SERVICE -> "故障/維修服務"
        CaseStatus.APPOINTMENT -> "有會勘/討論/到場安排"
        CaseStatus.INTERNAL_TASK -> "公司內部交辦${case.assignedTo?.let { "：$it" }.orEmpty()}"
        CaseStatus.NEED_FOLLOW_UP -> "需要追蹤進度"
        CaseStatus.OTHER -> "一般訊息"
        CaseStatus.RESOLVED -> "已結案"
    }

    private fun waitingLabel(waiting: WaitingFor): String = when (waiting) {
        WaitingFor.CUSTOMER -> "客戶"
        WaitingFor.VENDOR -> "廠商"
        WaitingFor.EXTERNAL -> "外部條件"
        WaitingFor.COMPANY -> "公司"
        WaitingFor.NONE -> "無"
    }

    private fun sameLocalDay(a: Long, b: Long): Boolean {
        val da = Instant.ofEpochMilli(a).atZone(zone).toLocalDate()
        val db = Instant.ofEpochMilli(b).atZone(zone).toLocalDate()
        return da == db
    }
}
