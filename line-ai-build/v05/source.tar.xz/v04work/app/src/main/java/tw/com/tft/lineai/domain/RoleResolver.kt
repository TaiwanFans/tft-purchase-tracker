package tw.com.tft.lineai.domain

import tw.com.tft.lineai.data.SpeakerRole

object RoleResolver {
    private val internalMarkers = listOf(
        "Joshua 建玄", "Joshua", "建玄",
        "111台灣電扇公司", "216全益畜牧器具", "555陳佑全",
        "台灣電扇公務機213", "777余沛瑤公務機", "0905915222怡臻公務機1",
        "108彥伯公務機2", "張秋金", "Joan(絨)"
    )

    private val partnerMarkers = listOf("彥伯Jack", "彥伯")

    fun roleOf(speaker: String?, conversationName: String?): SpeakerRole {
        val s = speaker.orEmpty()
        val c = conversationName.orEmpty()
        if (internalMarkers.any { s.contains(it, ignoreCase = true) }) return SpeakerRole.INTERNAL
        if (partnerMarkers.any { s.contains(it, ignoreCase = true) }) return SpeakerRole.PARTNER
        if (s.contains("廠商") || c.contains("廠商")) return SpeakerRole.VENDOR
        if (c.startsWith("公事") && s.isNotBlank()) return SpeakerRole.INTERNAL
        if (s.isNotBlank()) return SpeakerRole.CUSTOMER
        return SpeakerRole.UNKNOWN
    }

    fun isInternalConversation(conversationName: String): Boolean {
        val c = conversationName.trim()
        return c.startsWith("公事") ||
            c.startsWith("臨時文字") ||
            Regex("^\\d+傳").containsMatchIn(c) ||
            internalMarkers.any { c.equals(it, ignoreCase = true) }
    }

    fun assignedTo(text: String): String? {
        val normalized = text.replace("＠", "@").replace(Regex("\\s+"), " ")
        return when {
            Regex("@?Joshua\\s*建玄|@?建玄").containsMatchIn(normalized) -> "建玄"
            normalized.contains("林助理") -> "林助理"
            normalized.contains("吳組長") -> "吳組長"
            normalized.contains("余小姐") -> "余小姐"
            normalized.contains("陳課長") -> "陳課長"
            else -> null
        }
    }

    fun waitingTargetFromText(text: String, role: SpeakerRole): String? {
        val t = text.lowercase()
        if (listOf("等客戶", "待客戶", "客戶回覆", "客人回覆", "待確認數量").any(t::contains)) return "CUSTOMER"
        if (listOf("等廠商", "廠商回覆", "交期回覆", "待廠商").any(t::contains)) return "VENDOR"
        if (listOf("許可證", "農糧署", "縣府", "海關", "訂艙", "booking").any(t::contains)) return "EXTERNAL"
        return when (role) {
            SpeakerRole.INTERNAL, SpeakerRole.PARTNER -> null
            SpeakerRole.VENDOR -> null
            SpeakerRole.CUSTOMER -> null
            SpeakerRole.UNKNOWN -> null
        }
    }
}
